Thanks for purchase our theme.
These are languages file from our RTL demo, But make sure we have used Google Translate in these languages. 
So best is this use theme original file and translate by yourself. Because we don't know about Arabic language.
But if you still want to use these file just just replace files in.
root/wp-content/themes/betube/languages/ Replace files here.

Thanks